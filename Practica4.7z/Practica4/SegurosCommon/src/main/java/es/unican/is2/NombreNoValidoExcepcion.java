package es.unican.is2;


@SuppressWarnings("serial")
public class NombreNoValidoExcepcion extends Exception {
    public NombreNoValidoExcepcion() {
        super();
    }
}
