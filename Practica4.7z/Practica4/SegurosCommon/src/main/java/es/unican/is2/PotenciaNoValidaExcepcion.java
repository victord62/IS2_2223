package es.unican.is2;

public class PotenciaNoValidaExcepcion extends Exception {
    public PotenciaNoValidaExcepcion() {
        super();
    }
}
