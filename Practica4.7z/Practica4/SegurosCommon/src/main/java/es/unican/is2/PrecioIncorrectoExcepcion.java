package es.unican.is2;


@SuppressWarnings("serial")
public class PrecioIncorrectoExcepcion extends Exception {
    public PrecioIncorrectoExcepcion() {
        super();
    }
}