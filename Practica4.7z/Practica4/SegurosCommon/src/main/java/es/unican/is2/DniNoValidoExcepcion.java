package es.unican.is2;


@SuppressWarnings("serial")
public class DniNoValidoExcepcion extends Exception {
    public DniNoValidoExcepcion() {
        super();
    }
}