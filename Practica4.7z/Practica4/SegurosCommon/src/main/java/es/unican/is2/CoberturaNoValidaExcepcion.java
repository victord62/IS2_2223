package es.unican.is2;


@SuppressWarnings("serial")
public class CoberturaNoValidaExcepcion extends Exception {
    public CoberturaNoValidaExcepcion() {
        super();
    }
}