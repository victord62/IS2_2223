package es.unican.is2;


@SuppressWarnings("serial")
public class FechaNoValidaExcepcion extends Exception {
    public FechaNoValidaExcepcion() {
        super();
    }
}